<!DOCTYPE html>
<html>
<head>
<title>admin</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>	
<body id="top">
<div class="bgded overlay" style="background-image:url('images/demo/backgrounds/a.jpg');"> 
  <div class="wrapper row1">
    <header id="header" class="hoc clear"> 
      <div id="logo" class="fl_left">
        <h1><a href="index.html">Library</a></h1>
      </div>
      <nav id="mainav" class="fl_right">
        <ul class="clear">
         	<li><a href="index2.php?page=home">HOME</a></li>
			<li><a href="index2.php?page=tutorial">LOGOUT</a></li>
        </ul>
      </nav>
    </header>		
	</div>
	<div id="pageintro" class="hoc clear">
    <div class="flexslider basicslider">
      <ul class="slides">
      </ul>
    </div>
  </div>
</div>
 
	<div class="badan">
 
 
	<?php 
	if(isset($_GET['page'])){
		$page = $_GET['page'];
 
		switch ($page) {
			case 'home':
				include "index.php";
				break;
			case 'tutorial':
				include "logout.php";
				break;	
			default:
				echo "<center><h3>Maaf. Halaman tidak di temukan !</h3></center>";
				break;
		}
	?>
  	<?php
	}else{
		include "index.php";
	}
 
	 ?>
	</div>
</div>
</body>
</html>