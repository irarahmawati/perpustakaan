<?php 

include 'koneksi.php';
 
$id = $_POST['id'];
$judul_buku = $_POST['judul_buku'];
$isi = $_POST['isi'];
 
mysqli_query($koneksi,"update mahasiswa set judul_buku='$judul_buku', isi='$isi' where id='$id'");
 
header("location:index2.php");
 
?>