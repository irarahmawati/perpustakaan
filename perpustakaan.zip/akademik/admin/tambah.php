<html>
<head>
	<center><title>tambah</title></center>
</head>
	<link rel="stylesheet" href="login.css" type="text/css" href="">
<body>
 <center>
	<h3>Tambah Buku</h3>
</center>
	<form method="post" action="tambah_aksi.php">
			<div class="login-card">
		<table>
			<tr>			
				<td>Judul Buku</td>
				<td><input type="text" name="judul_buku"></td>
			</tr>
			<tr>
				<td>Isi</td>
				<td><textarea input type="text" name="isi"></textarea></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="SIMPAN"></td>
			</tr>		
		</table>
	</form>
<center><button><a href="index2.php">KEMBALI</a></button></center>
</body>
</html>